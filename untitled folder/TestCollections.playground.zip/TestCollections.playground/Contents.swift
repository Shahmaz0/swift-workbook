
var users  = ["John":[[0],[Int](repeating: 0, count: 5)],
              "Mary":[[0],[Int](repeating: 0, count: 5)],
              "Rob":[[0],[Int](repeating: 0, count: 5)]]

users["John"] = [[1500], [Int](repeating: Int.random(in: 0...1500), count: 5)]
users["Mary"] = [[1500], [Int](repeating: Int.random(in: 0...1500), count: 5)]
users["Rob"] = [[1500], [Int](repeating: Int.random(in: 0...1500), count: 5)]

if let userData = users["Mary"] {
    print("Mary's daily goal is \(userData[0][0]) steps and last steps covered in last five days are \(userData[1])")
} else {
    print("User Mary does not exist")
}

users["John"]?[1].append(1000)
users["Mary"]?[1].append(1000)
users["Rob"]?[1].append(1000)

users.removeValue(forKey: "Rob")

users["John"]?[1][0] = 2000
users["Mary"]?[1][0] = 2000

print(users)
