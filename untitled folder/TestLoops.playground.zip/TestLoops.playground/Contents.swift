// Define a structure for Item
struct Item {
    let name: String
    let pricePerUnit: Double
}

// Create 15 items from different categories (Indian items)
let items: [Item] = [
    Item(name: "Rice", pricePerUnit: 40.0),       // Price per kilogram
    Item(name: "Wheat", pricePerUnit: 35.0),      // Price per kilogram
    Item(name: "Daal", pricePerUnit: 120.0),      // Price per kilogram
    Item(name: "Paneer", pricePerUnit: 250.0),    // Price per kilogram
    Item(name: "Chicken", pricePerUnit: 200.0),   // Price per kilogram
    Item(name: "Fish", pricePerUnit: 300.0),      // Price per kilogram
    Item(name: "Milk", pricePerUnit: 50.0),       // Price per liter
    Item(name: "Curd", pricePerUnit: 60.0),       // Price per kilogram
    Item(name: "Ghee", pricePerUnit: 600.0),      // Price per liter
    Item(name: "Tea", pricePerUnit: 200.0),       // Price per kilogram
    Item(name: "Sugar", pricePerUnit: 45.0),      // Price per kilogram
    Item(name: "Salt", pricePerUnit: 20.0),       // Price per kilogram
    Item(name: "Potatoes", pricePerUnit: 25.0),   // Price per kilogram
    Item(name: "Tomatoes", pricePerUnit: 30.0),   // Price per kilogram
    Item(name: "Onions", pricePerUnit: 20.0)      // Price per kilogram
]

// Create a dictionary containing categories with a list of items and their quantities
var inventory: [String: [(item: Item, quantity: Int)]] = [
    "Grains": [
        (item: items[0], quantity: 10), // Rice (10 kg)
        (item: items[1], quantity: 8),  // Wheat (8 kg)
        (item: items[2], quantity: 5)   // Daal (5 kg)
    ],
    "Dairy and Poultry": [
        (item: items[3], quantity: 2),  // Paneer (2 kg)
        (item: items[4], quantity: 3),  // Chicken (3 kg)
        (item: items[6], quantity: 6)   // Milk (6 liters)
    ]
]

// Add details of one additional category (Vegetables)
inventory["Vegetables"] = [
    (item: items[12], quantity: 10),   // Potatoes (10 kg)
    (item: items[13], quantity: 6),    // Tomatoes (6 kg)
    (item: items[14], quantity: 8)     // Onions (8 kg)
]

// Calculate total for each category and grand total
var grandTotal = 0.0

for (category, itemsList) in inventory {
    var categoryTotal = 0.0
    for aItem in itemsList {
        categoryTotal += Double(aItem.quantity) * aItem.item.pricePerUnit
    }
    print("Total for \(category): ₹\(categoryTotal)")
    grandTotal += categoryTotal
}

print("Grand Total: ₹\(grandTotal)")
